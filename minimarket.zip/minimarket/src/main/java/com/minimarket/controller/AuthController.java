package com.minimarket.controller;

import com.minimarket.entity.Rol;
import com.minimarket.entity.Usuario;
import com.minimarket.repository.RolRepository;
import com.minimarket.repository.UsuarioRepository;
import com.minimarket.security.util.JwtUtil;
import com.minimarket.security.model.LoginRequest;
import com.minimarket.security.model.LoginResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private RolRepository rolRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        
        // PRIMERO: obtener el rol
        String rol = userDetails.getAuthorities().iterator().next().getAuthority();
        
        // SEGUNDO: generar el token con el rol
        String token = jwtUtil.generateToken(userDetails.getUsername(), rol);

        return ResponseEntity.ok(new LoginResponse(token, userDetails.getUsername(), rol));
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Usuario usuario) {
        if (usuarioRepository.findByUsername(usuario.getUsername()).isPresent()) {
            return ResponseEntity.badRequest().body("Error: El usuario ya existe");
        }
        
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        Rol rolCliente = rolRepository.findByNombre("CLIENTE")
            .orElseThrow(() -> new RuntimeException("Error: Rol CLIENTE no encontrado"));
        usuario.setRoles(Set.of(rolCliente));
        usuarioRepository.save(usuario);
        
        return ResponseEntity.ok("Usuario registrado exitosamente");
    }
}